import React from 'react'

const Thankyou = () => {
  return (
    <div>Thankyou! You will be  receive your package shortly!!</div>
  )
}

export default Thankyou